export default function calculateTotalCost(paintCost: number, laborCost: number): number {
  return paintCost + laborCost;
}
