export default function calculatePaintCost(paintRequired: number, costPerLiter: number): number {
  return paintRequired * costPerLiter;
}
