export { default } from './calculateCanvasSize';
