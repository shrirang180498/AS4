export default function estimatePaintingTime(area: number, paintingSpeed: number): number {
  return area / paintingSpeed;
}
