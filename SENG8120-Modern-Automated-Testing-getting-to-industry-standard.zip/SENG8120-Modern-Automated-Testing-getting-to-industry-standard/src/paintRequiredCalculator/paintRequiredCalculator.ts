export default function paintRequiredCalculator(area: number, coveragePerLiter: number): number {
  return area / coveragePerLiter;
}
