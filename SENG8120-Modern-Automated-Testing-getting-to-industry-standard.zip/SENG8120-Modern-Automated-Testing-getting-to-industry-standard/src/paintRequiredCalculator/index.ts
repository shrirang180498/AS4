export { default } from "./paintRequiredCalculator";
