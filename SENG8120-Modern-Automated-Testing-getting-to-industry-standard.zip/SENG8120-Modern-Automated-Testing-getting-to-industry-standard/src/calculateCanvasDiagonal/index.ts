export { default } from "./calculateCanvasDiagonal";
